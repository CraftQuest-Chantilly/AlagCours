<?php
// Configuration de l'API du portail stagiaire (alaginfo.net/alcours/api/).
// Les valeurs sensibles (base, secret des jetons) sont dans config.local.php,
// qui n'est PAS versionné : copier config.local.example.php et le remplir.
$config = [
    // Connexion PostgreSQL (aujourd'hui la base Postgres de Supabase, demain le VPS :
    // seul ce DSN change, l'API n'utilise que du SQL standard).
    'db_dsn'      => '',
    'db_user'     => '',
    'db_password' => '',
    // Secret HMAC des jetons de session (au moins 32 caractères aléatoires).
    'jwt_secret'  => '',
    'jwt_duree'   => 8 * 3600,           // durée de validité d'une session (secondes)
    'fuseau'      => 'Europe/Paris',
    // Anti force brute : au-delà de N échecs sur la fenêtre, connexion refusée.
    'echecs_max'     => 5,              // par identifiant
    'echecs_max_ip'  => 30,             // par adresse IP
    'echecs_fenetre' => 15 * 60,         // secondes
];
$local = __DIR__ . '/config.local.php';
if (is_file($local)) {
    $config = array_merge($config, require $local);
}
return $config;
