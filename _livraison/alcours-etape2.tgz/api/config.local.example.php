<?php
// Copier ce fichier en config.local.php (même dossier) et renseigner les valeurs.
// config.local.php ne doit jamais être publié ni versionné.
return [
    'db_dsn'      => 'pgsql:host=HOTE;port=5432;dbname=postgres;sslmode=require',
    'db_user'     => 'UTILISATEUR',
    'db_password' => 'MOT_DE_PASSE',
    'jwt_secret'  => 'REMPLACER_PAR_UNE_CHAINE_ALEATOIRE_DE_64_CARACTERES',
];
