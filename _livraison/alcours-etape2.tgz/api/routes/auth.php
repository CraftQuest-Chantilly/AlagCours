<?php
// Connexion stagiaire : reprend PAGE__Login d'al-cours (branche stagiaire).
// Identifiant = T_Stagiaire.Stag_Login, mot de passe = T_Stagiaire.Stag_Mdp.
// Différences volontaires avec l'original, signalées dans recap-etape-2.md :
//  - le mot de passe saisi n'est PLUS écrit dans TS_LOG (l'original le journalisait en clair) ;
//  - le captcha après 3 échecs est remplacé par un blocage côté serveur
//    (N échecs sur une fenêtre de temps, comptés dans TS_LOG) ;
//  - un login présent sur plusieurs stagiaires est refusé (l'original prenait le premier).

function journaliser_connexion(string $identifiant, string $statut, ?string $codeUser, string $info = ''): void
{
    Db::exec(
        'INSERT INTO "TS_LOG" ("LOG_Date","LOG_Heure","LOG_Identifiant","LOG_IP","LOG_Co_Deco","LOG_CodeUser","LOG_Info","LOG_Out","LOG_HeureDerGo")
         VALUES (:d, :h, :id, :ip, :st, :cu, :info, false, :h)',
        [
            ':d' => date('Y-m-d'), ':h' => date('H:i:s'),
            ':id' => mb_substr($identifiant, 0, 50), ':ip' => Http::ip(),
            ':st' => $statut, ':cu' => $codeUser, ':info' => mb_substr($info, 0, 50),
        ]
    );
}

function trop_d_echecs(string $identifiant): bool
{
    // Deux compteurs : par identifiant (seuil bas) et par adresse IP (seuil haut, car une
    // salle de formation entière sort souvent sur la même IP publique).
    $c = $GLOBALS['config'];
    $depuis = date('Y-m-d H:i:s', time() - (int)$c['echecs_fenetre']);
    $r = Db::ligne(
        'SELECT count(*) FILTER (WHERE "LOG_Identifiant" = :id) AS par_login,
                count(*) FILTER (WHERE "LOG_IP" = :ip) AS par_ip
           FROM "TS_LOG"
          WHERE "LOG_Co_Deco" = \'Echec_Co\' AND ("LOG_Date" + "LOG_Heure") >= :depuis',
        [':id' => $identifiant, ':ip' => Http::ip(), ':depuis' => $depuis]
    );
    return (int)$r['par_login'] >= (int)$c['echecs_max'] || (int)$r['par_ip'] >= (int)$c['echecs_max_ip'];
}

function route_login(): void
{
    $d = Http::corps();
    $login = trim((string)($d['login'] ?? ''));
    $mdp = (string)($d['mdp'] ?? '');
    if ($login === '' || $mdp === '') Http::erreur(400, 'Identifiant et mot de passe obligatoires.');

    if (trop_d_echecs($login)) {
        Http::erreur(429, 'Trop de tentatives. Réessayez dans quelques minutes.');
    }

    $lignes = Db::lignes(
        'SELECT "Stag_CodeStagiaire"::text AS code, "Stag_Nom" AS nom, "Stag_Prenom" AS prenom,
                "Stag_Login" AS login, "Stag_Mdp" AS mdp
           FROM "T_Stagiaire" WHERE "Stag_Login" = :l',
        [':l' => $login]
    );

    if (count($lignes) > 1) {
        journaliser_connexion($login, 'Echec_Co', null, 'Login en double');
        Http::erreur(409, 'Cet identifiant est partagé par plusieurs comptes. Contactez votre formateur.');
    }

    $s = $lignes[0] ?? null;
    $stocke = (string)($s['mdp'] ?? '');
    $ok = false;
    if ($s && $stocke !== '') {
        // Compatible avec un futur stockage haché (bcrypt), sinon comparaison à temps constant.
        $ok = preg_match('/^\$2[aby]\$/', $stocke) ? password_verify($mdp, $stocke) : hash_equals($stocke, $mdp);
    }

    if (!$ok) {
        journaliser_connexion($login, 'Echec_Co', $s['code'] ?? null);
        Http::erreur(401, 'Identifiant ou mot de passe incorrect.');
    }

    journaliser_connexion($login, 'Co', $s['code'], 'Portail alcours');

    $jeton = Jeton::emettre([
        'typ' => 'stagiaire',
        'sub' => $s['code'],
        'nom' => $s['nom'],
        'prenom' => $s['prenom'],
    ]);

    Http::json([
        'jeton' => $jeton,
        'stagiaire' => [
            'code' => $s['code'],
            'nom' => $s['nom'],
            'prenom' => $s['prenom'],
            // Mot de passe provisoire (= identifiant) : le front affiche un avertissement.
            'mdpProvisoire' => $stocke === $s['login'],
        ],
    ]);
}

function route_me(): void
{
    $c = Jeton::stagiaire();
    $s = Db::ligne(
        'SELECT "Stag_CodeStagiaire"::text AS code, "Stag_Nom" AS nom, "Stag_Prenom" AS prenom,
                ("Stag_Mdp" = "Stag_Login") AS "mdpProvisoire"
           FROM "T_Stagiaire" WHERE "Stag_CodeStagiaire" = :c',
        [':c' => $c['sub']]
    );
    if (!$s) Http::erreur(401, 'Compte introuvable.');
    Http::json($s);
}
