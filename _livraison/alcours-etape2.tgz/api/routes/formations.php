<?php
// Formations (promos) du stagiaire connecté : reprend PAGE__ChoixCours et PAGE__Accueil d'al-cours.

/** Inscription active du stagiaire à la promo, sinon 404 (on ne révèle pas l'existence de la promo). */
function inscription(string $codeStag, string $codePromo): array
{
    $i = Db::ligne(
        'SELECT "PromSta_Groupe" AS groupe FROM "T_Promo_Stagiaire"
          WHERE "PromSta_CodeStagiaire" = :s AND "PromSta_CodePromo" = :p AND "PromSta_Actif"
          LIMIT 1',
        [':s' => $codeStag, ':p' => $codePromo]
    );
    if (!$i) Http::erreur(404, 'Formation introuvable.');
    return $i;
}

/** Liste des formations (tableau « Choisir un cours » : Libellé, Sujet, V, SujetNiv, NbJours, Du, Au). */
function route_formations(): void
{
    $c = Jeton::stagiaire();
    $r = Db::lignes(
        'SELECT p."Pro_CodePromo"::text AS code, p."Pro_Libelle" AS libelle, p."Pro_SujetForm" AS sujet,
                p."Pro_SujetVersion" AS version, p."Pro_SujetNiv" AS niveau, p."Pro_NbJours" AS "nbJours",
                p."Pro_Du" AS du, p."Pro_Au" AS au, ps."PromSta_Groupe" AS groupe
           FROM "T_Promo_Stagiaire" ps
           JOIN "T_Promo" p ON p."Pro_CodePromo" = ps."PromSta_CodePromo"
          WHERE ps."PromSta_CodeStagiaire" = :s AND ps."PromSta_Actif"
          ORDER BY p."Pro_Du" DESC NULLS LAST, p."Pro_Libelle"',
        [':s' => $c['sub']]
    );
    Http::json($r);
}

/** Tableau de bord d'une formation (PAGE__Accueil) : en-tête + modules à afficher. */
function route_formation(string $codePromo): void
{
    $c = Jeton::stagiaire();
    $i = inscription($c['sub'], $codePromo);
    $p = Db::ligne(
        'SELECT "Pro_CodePromo"::text AS code, "Pro_Libelle" AS libelle, "Pro_SujetForm" AS sujet,
                "Pro_Du" AS du, "Pro_Au" AS au, "Pro_Doc1" AS doc1
           FROM "T_Promo" WHERE "Pro_CodePromo" = :p',
        [':p' => $codePromo]
    );
    if (!$p) Http::erreur(404, 'Formation introuvable.');

    // Même règle que l'original : un module n'apparaît que si son marqueur figure dans Pro_Doc1
    // (Contient() WLangage, sensible à la casse). Pour « Avis », l'original évaluait deux
    // conditions successives ; la seconde (marqueur -Avis-) écrasait la première : on garde la seconde.
    $doc1 = (string)$p['doc1'];
    $a = function (string $marqueur) use ($doc1): bool { return strpos($doc1, $marqueur) !== false; };
    $modules = [
        'testPositionnement' => $a('-Test de positionnement-'),
        'signature'          => $a('-signature-'),
        'ressources'         => true,
        'quizz'              => $a('-Quizz-'),
        'evaluation'         => $a('-Evaluation de la formation-'),
        'avis'               => $a('-Avis-'),
    ];
    unset($p['doc1']);
    $p['groupe'] = $i['groupe'];
    $p['commence'] = $p['du'] !== null && $p['du'] <= date('Y-m-d');
    $p['modules'] = $modules;
    Http::json($p);
}

/** Séances de la formation visibles par le groupe du stagiaire (agenda). */
function route_seances(string $codePromo): void
{
    $c = Jeton::stagiaire();
    $i = inscription($c['sub'], $codePromo);
    $r = Db::lignes(
        'SELECT co."Cours_NumCours"::text AS code, co."Cours_Date" AS date,
                to_char(co."Cours_HeureDebut", \'HH24:MI\') AS debut, to_char(co."Cours_HeureFin", \'HH24:MI\') AS fin,
                co."Cours_NumX" AS "numTd", co."Cours_Groupe" AS groupe, co."Cours_Salle" AS salle,
                co."Cours_Adresse" AS adresse, f."Forma_Initiales" AS formateur
           FROM "T_Cours" co
           LEFT JOIN "T_Formateur" f ON f."Forma_CodeFormateur" = co."Cours_CodeFormateur"
          WHERE co."Cours_CodePromo" = :p
            AND (co."Cours_GroupeEntier" OR COALESCE(co."Cours_Groupe", \'\') = \'\' OR co."Cours_Groupe" = :g)
          ORDER BY co."Cours_Date", co."Cours_HeureDebut"',
        [':p' => $codePromo, ':g' => (string)$i['groupe']]
    );
    Http::json($r);
}

/** Toutes les séances de toutes les formations actives (agenda de « Mes formations »). */
function route_agenda(): void
{
    $c = Jeton::stagiaire();
    $r = Db::lignes(
        'SELECT co."Cours_NumCours"::text AS code, p."Pro_CodePromo"::text AS "codePromo", p."Pro_Libelle" AS libelle,
                co."Cours_Date" AS date,
                to_char(co."Cours_HeureDebut", \'HH24:MI\') AS debut, to_char(co."Cours_HeureFin", \'HH24:MI\') AS fin,
                co."Cours_NumX" AS "numTd"
           FROM "T_Cours" co
           JOIN "T_Promo" p ON p."Pro_CodePromo" = co."Cours_CodePromo"
           JOIN "T_Promo_Stagiaire" ps ON ps."PromSta_CodePromo" = p."Pro_CodePromo"
                AND ps."PromSta_CodeStagiaire" = :s AND ps."PromSta_Actif"
          WHERE (co."Cours_GroupeEntier" OR COALESCE(co."Cours_Groupe", \'\') = \'\' OR co."Cours_Groupe" = ps."PromSta_Groupe")
          ORDER BY co."Cours_Date", co."Cours_HeureDebut"',
        [':s' => $c['sub']]
    );
    Http::json($r);
}
