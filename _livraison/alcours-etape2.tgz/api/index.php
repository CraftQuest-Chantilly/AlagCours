<?php
// API du portail stagiaire al-cours — point d'entrée unique (IIS réécrit tout vers ce fichier).
// PHP >= 7.4, extension pdo_pgsql. Aucune dépendance externe.
declare(strict_types=1);

$config = require __DIR__ . '/config.php';
date_default_timezone_set($config['fuseau']);

require __DIR__ . '/lib/Http.php';
require __DIR__ . '/lib/Db.php';
require __DIR__ . '/lib/Jeton.php';
require __DIR__ . '/routes/auth.php';
require __DIR__ . '/routes/formations.php';

set_exception_handler(function (Throwable $e) {
    error_log('[alcours api] ' . $e->getMessage() . ' @ ' . $e->getFile() . ':' . $e->getLine());
    Http::erreur(500, 'Erreur interne du serveur.');
});

// Chemin de la route, relatif au dossier de l'API (ex. /alcours/api/formations -> /formations).
$base = rtrim(str_replace('\\', '/', dirname($_SERVER['SCRIPT_NAME'])), '/');
$chemin = parse_url($_SERVER['REQUEST_URI'] ?? '/', PHP_URL_PATH) ?: '/';
if ($base !== '' && strpos($chemin, $base) === 0) $chemin = substr($chemin, strlen($base));
$chemin = '/' . trim(preg_replace('#^/index\.php#', '', $chemin), '/');
$methode = $_SERVER['REQUEST_METHOD'] ?? 'GET';

$routes = [
    ['POST', '#^/login$#',                     'route_login'],
    ['GET',  '#^/me$#',                        'route_me'],
    ['GET',  '#^/formations$#',                'route_formations'],
    ['GET',  '#^/agenda$#',                    'route_agenda'],
    ['GET',  '#^/formations/(\d+)$#',          'route_formation'],
    ['GET',  '#^/formations/(\d+)/seances$#',  'route_seances'],
];

foreach ($routes as [$m, $motif, $fn]) {
    if ($m === $methode && preg_match($motif, $chemin, $args)) {
        array_shift($args);
        $fn(...array_map([Http::class, 'id'], $args));
        exit;
    }
}
Http::erreur(404, 'Route inconnue.');
