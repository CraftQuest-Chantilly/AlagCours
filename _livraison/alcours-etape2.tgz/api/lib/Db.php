<?php
// Accès PostgreSQL via PDO. SQL standard uniquement (aucune fonction propre à Supabase).
final class Db
{
    private static ?PDO $pdo = null;

    public static function pdo(): PDO
    {
        if (self::$pdo === null) {
            $c = $GLOBALS['config'];
            try {
                self::$pdo = new PDO($c['db_dsn'], $c['db_user'], $c['db_password'], [
                    PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
                    PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
                    PDO::ATTR_EMULATE_PREPARES => false,
                ]);
            } catch (PDOException $e) {
                error_log('Connexion base impossible : ' . $e->getMessage());
                Http::erreur(503, 'Base de données indisponible.');
            }
        }
        return self::$pdo;
    }

    public static function lignes(string $sql, array $params = []): array
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->fetchAll();
    }

    public static function ligne(string $sql, array $params = []): ?array
    {
        $r = self::lignes($sql, $params);
        return $r[0] ?? null;
    }

    public static function exec(string $sql, array $params = []): int
    {
        $st = self::pdo()->prepare($sql);
        $st->execute($params);
        return $st->rowCount();
    }
}
