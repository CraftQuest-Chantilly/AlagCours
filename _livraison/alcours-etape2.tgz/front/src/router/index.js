import { createRouter, createWebHistory } from 'vue-router'
import { useAuthStore } from '@/stores/auth'

const routes = [
  { path: '/connexion', name: 'connexion', component: () => import('@/pages/ConnexionPage.vue') },
  {
    path: '/',
    component: () => import('@/components/AppLayout.vue'),
    meta: { requiresAuth: true },
    children: [
      { path: '', name: 'formations', component: () => import('@/pages/FormationsPage.vue') },
      { path: 'formations/:code', name: 'formation', component: () => import('@/pages/FormationPage.vue'), props: true }
    ]
  },
  { path: '/:pathMatch(.*)*', redirect: '/' }
]

const router = createRouter({ history: createWebHistory(import.meta.env.BASE_URL), routes })

router.beforeEach((to) => {
  const auth = useAuthStore()
  if (to.meta.requiresAuth && !auth.connecte) return { name: 'connexion' }
  if (to.name === 'connexion' && auth.connecte) return { name: 'formations' }
})

export default router
