// Session du stagiaire : jeton émis par l'API PHP + identité. Stockée en sessionStorage :
// fermer l'onglet déconnecte (même choix que l'appli formateur SuiviCours).
import { defineStore } from 'pinia'
import { api } from '@/services/api'

export const useAuthStore = defineStore('auth', {
  state: () => ({ jeton: null, stagiaire: null }),
  getters: {
    connecte: (s) => !!s.jeton,
    nomComplet: (s) => (s.stagiaire ? `${s.stagiaire.prenom ?? ''} ${s.stagiaire.nom ?? ''}`.trim() : '')
  },
  actions: {
    async connecter(login, mdp) {
      const r = await api('/login', { method: 'POST', body: { login, mdp } })
      this.jeton = r.jeton
      this.stagiaire = r.stagiaire
    },
    effacer() {
      this.jeton = null
      this.stagiaire = null
    }
  },
  persist: { storage: sessionStorage }
})
