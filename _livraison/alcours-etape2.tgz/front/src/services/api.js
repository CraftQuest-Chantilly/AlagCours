// Appels à l'API PHP du portail (/alcours/api/…). Le jeton de session est envoyé en en-tête.
// Toute réponse 401 (session absente/expirée) renvoie à l'écran de connexion.
import { useAuthStore } from '@/stores/auth'
import router from '@/router'

const BASE = `${import.meta.env.BASE_URL}api`

export async function api(chemin, { method = 'GET', body } = {}) {
  const auth = useAuthStore()
  const headers = { Accept: 'application/json' }
  if (body !== undefined) headers['Content-Type'] = 'application/json'
  if (auth.jeton) headers.Authorization = `Bearer ${auth.jeton}`

  let rep
  try {
    rep = await fetch(`${BASE}${chemin}`, { method, headers, body: body !== undefined ? JSON.stringify(body) : undefined })
  } catch {
    throw new Error('Serveur injoignable. Vérifiez votre connexion internet.')
  }
  const data = await rep.json().catch(() => null)
  if (rep.status === 401 && chemin !== '/login') {
    auth.effacer()
    router.push({ name: 'connexion', query: { expire: '1' } })
  }
  if (!rep.ok) throw new Error(data?.erreur || `Erreur ${rep.status}`)
  return data
}
