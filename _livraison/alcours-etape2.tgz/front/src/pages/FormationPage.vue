<script setup>
// Remplace PAGE__Accueil d'al-cours : en-tête de la formation + modules.
// Un module n'apparaît que si son marqueur figure dans Pro_Doc1 (règle d'origine, calculée par l'API).
// Les modules non encore reconstruits sont affichés « bientôt disponible ».
import { computed, onMounted, ref } from 'vue'
import { api } from '@/services/api'
import { dateFr } from '@/utils'

const props = defineProps({ code: { type: String, required: true } })

const formation = ref(null)
const seances = ref([])
const erreur = ref('')
const chargement = ref(true)

onMounted(async () => {
  try {
    ;[formation.value, seances.value] = await Promise.all([
      api(`/formations/${props.code}`),
      api(`/formations/${props.code}/seances`)
    ])
  } catch (e) {
    erreur.value = e.message
  } finally {
    chargement.value = false
  }
})

// Ordre et libellés repris des boutons de PAGE__Accueil.
const CATALOGUE = [
  { cle: 'testPositionnement', titre: 'Test de positionnement', icone: '?', apresDebut: false },
  { cle: 'signature', titre: 'Signature feuille de présence', icone: '✍', apresDebut: false },
  { cle: 'ressources', titre: 'Fichiers, exercices, ressources', icone: '📁', apresDebut: false },
  { cle: 'quizz', titre: 'Quizz', icone: '❓', apresDebut: true },
  { cle: 'evaluation', titre: 'Évaluation de la formation', icone: '📝', apresDebut: true },
  { cle: 'avis', titre: 'Avis', icone: '★', apresDebut: false }
]

const modules = computed(() => CATALOGUE.filter((m) => formation.value?.modules?.[m.cle]))
</script>

<template>
  <div class="space-y-6">
    <RouterLink :to="{ name: 'formations' }" class="text-sm text-alag-blue-dark hover:underline">‹ Mes formations</RouterLink>

    <p v-if="erreur" class="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700" role="alert">{{ erreur }}</p>
    <p v-else-if="chargement" class="text-sm text-slate-500">Chargement…</p>

    <template v-else-if="formation">
      <section class="sc-card grid gap-3 p-4 sm:grid-cols-3">
        <div>
          <div class="text-xs font-semibold uppercase tracking-wide text-slate-500">Cours</div>
          <div class="font-semibold text-slate-900">{{ formation.libelle }} <span class="font-normal text-slate-600">{{ formation.sujet }}</span></div>
        </div>
        <div>
          <div class="text-xs font-semibold uppercase tracking-wide text-slate-500">Dates</div>
          <div>Du {{ dateFr(formation.du) }} au {{ dateFr(formation.au) }}</div>
        </div>
        <div>
          <div class="text-xs font-semibold uppercase tracking-wide text-slate-500">Groupe</div>
          <div>{{ formation.groupe || '—' }}</div>
        </div>
      </section>

      <section>
        <h2 class="mb-3 text-base font-semibold text-alag-navy">Modules</h2>
        <div class="grid gap-3 sm:grid-cols-2 lg:grid-cols-3">
          <div v-for="m in modules" :key="m.cle" data-test="module"
               class="flex items-center justify-between gap-3 rounded-xl bg-[#0f5a7d] px-4 py-4 text-white opacity-80 shadow-sm">
            <div>
              <div class="font-semibold">{{ m.titre }}</div>
              <div class="text-xs text-white/80">
                {{ m.apresDebut && !formation.commence ? 'Disponible quand la formation aura commencé' : 'Bientôt disponible' }}
              </div>
            </div>
            <span class="text-2xl" aria-hidden="true">{{ m.icone }}</span>
          </div>
        </div>
      </section>

      <section class="sc-card overflow-hidden">
        <h2 class="px-4 pt-4 text-base font-semibold text-alag-navy">Séances</h2>
        <p v-if="!seances.length" class="p-4 text-sm text-slate-600">Aucune séance planifiée pour votre groupe.</p>
        <ul v-else class="mt-2 divide-y divide-slate-100 text-sm">
          <li v-for="s in seances" :key="s.code" class="flex flex-wrap items-baseline gap-x-4 gap-y-1 px-4 py-2">
            <span class="w-40 font-medium capitalize">{{ dateFr(s.date, { weekday: 'short', day: '2-digit', month: '2-digit', year: 'numeric' }) }}</span>
            <span class="w-24">{{ s.debut }}–{{ s.fin }}</span>
            <span v-if="s.numTd" class="w-20 text-slate-600">TD {{ s.numTd }}</span>
            <span class="text-slate-600">{{ s.salle }}</span>
            <span v-if="s.formateur" class="ml-auto text-xs text-slate-500">Formateur : {{ s.formateur }}</span>
          </li>
        </ul>
      </section>
    </template>
  </div>
</template>
